#include <stdio.h>
#include <unistd.h>
int main() {
   // printf() displays the string inside quotation
   sleep(50);
   printf("SLEPT FOR LONG!\n");
   return 0;
}

