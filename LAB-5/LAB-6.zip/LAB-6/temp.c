#include<stdlib.h>
#include<stdio.h>

int main(){
int n;
scanf("%d",&n);
printf("%d is the input no.", n);
    return 0;
}