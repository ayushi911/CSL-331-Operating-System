#include <stdio.h>
#include <unistd.h>
int main() {
   // printf() displays the string inside quotation
   sleep(6);
   printf("SLEEP OVER!\n");
   return 0;
}

